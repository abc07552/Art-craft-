# Craft Anything AI PRO — Android port starter

This folder is an Android-native hybrid starter built around the supplied upstream Craft Anything source. It preserves the complete upstream repository under `upstream/craft-anything-main/`.

## Important scope statement

This is **not yet a feature-complete Android port of the upstream engine**. The supplied upstream README describes a Rust desktop app + CLI and a deliberately limited browser viewer. The browser app's own `main.rs` says it only runs the wasm-safe file viewer; it excludes the engine, platform and AI crates. The Android app here currently provides a native dashboard, local project-brief storage, basic HTTPS HEAD metadata inspection, encrypted API-key preferences, and optional OpenAI-compatible Chat Completions planning. It does not yet run the upstream 320-tool Rust engine, instrument installed apps/games, capture browser pages/screenshots, execute a coding agent, or compare generated builds. Those require dedicated Android-compatible Rust/FFI modules and a trusted worker service.

## Build APK from an Android phone (GitHub Actions)

1. Extract this ZIP on your phone.
2. Create a GitHub repository and upload the **contents** of this folder (not the ZIP file). Easiest: GitHub app/site → new repository → Add file → Upload files. For a large upstream folder, use GitHub's web upload in batches or GitHub mobile/Termux git.
3. Open the repository → **Actions** → **Build Android APK** → **Run workflow**.
4. Wait for the green success check.
5. Open the workflow run → Artifacts → download `craft-anything-ai-pro-debug-apk`.
6. Extract the artifact ZIP and install `app-debug.apk`. Android may ask you to allow installation from that source.

## Build on a computer

Install JDK 17 and Android SDK (platform 35 + build tools), then run from this directory:

```bash
gradle assembleDebug
```

APK output: `app/build/outputs/apk/debug/app-debug.apk`.

## Configure cloud AI

Open Settings and enter an OpenAI-compatible HTTPS base URL, model ID, and API key. Example base URL: `https://api.openai.com/v1`. Save. API provider usage may cost money. Keep your key private. For production, route requests through your own authenticated backend rather than shipping long-lived provider keys in a distributed APK.

## Hybrid architecture roadmap

- Phase 1 (included): Android shell, local project briefs, basic URL metadata, encrypted settings, optional cloud planning.
- Phase 2: extract platform-neutral Rust crates from upstream and expose a narrowly scoped JNI interface; add Android file-picker/document-provider access and bounded background jobs.
- Phase 3: implement web capture (WebView + accessibility/DOM where permitted), Android APK static inspection, evidence ledger, and report export.
- Phase 4: add a remote coding-worker API with explicit user approval, isolated workspaces, command allowlists, audit logs and downloadable project artifacts.
- Phase 5: add visual comparison and regression checks; sign release APK/AAB.

## Upstream source

The original source is included in `upstream/craft-anything-main/`. See its README, `Cargo.toml`, and `apps/craft-anything-web/` for supported targets and build constraints. Preserve its MIT/Apache notices when redistributing.

## JNI + upstream Rust parser module (added)

The `native/` Cargo crate builds `libcraft_anything_android.so` for `arm64-v8a` and `armeabi-v7a`. It calls the supplied upstream `craft-anything-formats`, `craft-anything-analysis` and `craft-anything-disasm` crates directly and exports three JNI methods:

- `NativeEngine.inspectApk(bytes)`: ZIP/APK container checks (manifest, DEX entries, resources and signature-block presence).
- `NativeEngine.analyzeBinary(bytes)`: upstream executable parser plus native triage and bounded function/control-flow analysis for supported ELF, PE, Mach-O, COFF and DOS formats.
- `NativeEngine.extractStrings(bytes)`: upstream bounded ASCII/UTF-8/UTF-16LE string extraction.

The Android Inspect tab uses the system document picker and runs these parsers locally. Input is capped at 64 MiB. The report is static analysis only; it does not run, instrument, modify, decrypt or bypass protections in the selected app.

### Rust/JNI build pipeline

The GitHub Actions workflow now installs Android NDK 27.2, Rust stable, Android Rust targets and `cargo-ndk`, builds both native ABIs, then packages the shared libraries into the APK. Run **Actions → Build Craft Anything AI PRO Android APK → Run workflow**. Download the `craft-anything-ai-pro-debug-apk` artifact.

### Agent module scope

The Agent tab submits a structured task brief to the configured OpenAI-compatible endpoint and formats the response as a reviewable work order (planner module, not an autonomous coding executor). It does **not** execute model-generated shell commands or write generated source files. Real coding-agent execution requires a separately deployed, authenticated worker with isolated workspaces, command allowlists, audit logging, resource limits and per-action human approval. The desktop engine's process and agent adapters are not being represented as Android-ready merely because the pure-Rust parser crate is available.

### Build prerequisites and status

A GitHub Actions build is required to validate the NDK/JNI integration and produce the APK. This environment does not have Cargo, Gradle or the Android SDK installed, so the native library and APK have not been compiled or device-tested here. The Rust dependency graph pulls the upstream parser crate's pinned `craft-libs` dependencies from Git during the CI build.
