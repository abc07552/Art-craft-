package ai.storyteller.craftanything

import android.os.Bundle
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import ai.storyteller.craftanything.agent.CodingAgent
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.TimeUnit

private val Navy = Color(0xFF0B1020)
private val Panel = Color(0xFF151D32)
private val Accent = Color(0xFF8997FF)
private val Muted = Color(0xFF9AA8C7)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme(colorScheme = darkColorScheme(primary = Accent, background = Navy, surface = Panel)) { CraftApp(this) } }
    }
}

@Composable
private fun CraftApp(activity: ComponentActivity) {
    val scope = rememberCoroutineScope()
    val prefs = remember { securePrefs(activity) }
    var endpoint by remember { mutableStateOf(prefs.getString("endpoint", "https://api.openai.com/v1") ?: "https://api.openai.com/v1") }
    var apiKey by remember { mutableStateOf(prefs.getString("key", "") ?: "") }
    var model by remember { mutableStateOf(prefs.getString("model", "gpt-4.1-mini") ?: "gpt-4.1-mini") }
    var target by remember { mutableStateOf("") }
    var request by remember { mutableStateOf("") }
    var projectName by remember { mutableStateOf("My first project") }
    var output by remember { mutableStateOf("Welcome. Create a project or inspect a public website to begin.") }
    var busy by remember { mutableStateOf(false) }
    var tab by remember { mutableStateOf(0) }
    var selectedFileName by remember { mutableStateOf("No file selected") }
    val context = activity
    val filePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            scope.launch {
                busy = true
                output = withContext(Dispatchers.IO) {
                    try {
                        val bytes = context.contentResolver.openInputStream(uri)?.use { stream ->
                            val out = java.io.ByteArrayOutputStream()
                            val buffer = ByteArray(8192)
                            var total = 0
                            while (true) {
                                val count = stream.read(buffer)
                                if (count < 0) break
                                total += count
                                require(total <= 64 * 1024 * 1024) { "Choose a file smaller than 64 MiB." }
                                out.write(buffer, 0, count)
                            }
                            out.toByteArray()
                        } ?: error("Cannot read selected file")
                        val name = uri.lastPathSegment?.substringAfterLast('/') ?: "selected file"
                        selectedFileName = name
                        if (name.endsWith(".apk", true)) NativeEngine.inspectApk(bytes)
                        else NativeEngine.analyzeBinary(bytes) + "\n\nSTRING EXTRACTION\n" + NativeEngine.extractStrings(bytes)
                    } catch (e: Throwable) { "Native inspection failed: ${e.message}" }
                }
                busy = false
            }
        }
    }

    Column(Modifier.fillMaxSize().background(Navy).statusBarsPadding()) {
        Row(Modifier.fillMaxWidth().padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
            Surface(shape = RoundedCornerShape(14.dp), color = Accent.copy(alpha = .18f)) { Icon(Icons.Default.AutoAwesome, null, tint = Accent, modifier = Modifier.padding(12.dp).size(25.dp)) }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) { Text("CRAFT ANYTHING", color = Color.White, fontWeight = FontWeight.Black); Text("AI PRO  ·  ANDROID", color = Muted, style = MaterialTheme.typography.labelSmall) }
            Icon(Icons.Default.CloudDone, null, tint = Color(0xFF6EE7B7))
        }
        NavigationBar(containerColor = Panel) {
            listOf("Home", "Build", "Inspect", "Agent", "Settings").forEachIndexed { i, s -> NavigationBarItem(selected = tab == i, onClick = { tab = i }, icon = { Icon(listOf(Icons.Default.Dashboard, Icons.Default.Code, Icons.Default.Search, Icons.Default.SmartToy, Icons.Default.Settings)[i], null) }, label = { Text(s) }) }
        }
        when (tab) {
            0 -> LazyColumn(Modifier.weight(1f).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                item { Text("Your creative workbench", color = Color.White, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold) }
                item { Text("Study → Build → Check → Refine", color = Muted) }
                item { StatCard("PROJECT WORKSPACE", "Local projects", "Saved privately on this device", Icons.Default.Folder) }
                item { StatCard("HYBRID AI", if (apiKey.isBlank()) "Not configured" else "Provider configured", "Local project files + optional cloud model", Icons.Default.Cloud) }
                item { StatCard("SOURCE ENGINE", "JNI analysis connected", "Upstream format, triage and bounded disassembly modules", Icons.Default.Memory) }
                item { Button(onClick = { tab = 1 }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Add, null); Spacer(Modifier.width(8.dp)); Text("Create a project") } }
                item { Text("Build status", color = Color.White, fontWeight = FontWeight.Bold) }
                item { Text(output, color = Muted) }
            }
            1 -> LazyColumn(Modifier.weight(1f).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                item { Text("New AI project", color = Color.White, style = MaterialTheme.typography.headlineSmall) }
                item { OutlinedTextField(projectName, { projectName = it }, label = { Text("Project name") }, modifier = Modifier.fillMaxWidth()) }
                item { OutlinedTextField(target, { target = it }, label = { Text("Target URL (optional)") }, placeholder = { Text("https://example.com") }, modifier = Modifier.fillMaxWidth()) }
                item { OutlinedTextField(request, { request = it }, label = { Text("What do you want to build?") }, minLines = 4, modifier = Modifier.fillMaxWidth()) }
                item { Button(enabled = !busy && request.isNotBlank(), onClick = { busy = true; scope.launch { output = createProject(context, projectName, target, request); busy = false } }, modifier = Modifier.fillMaxWidth()) { Text(if (busy) "Saving…" else "Create local project") } }
                item { Text("This creates a local project brief. To generate code with a model, configure Settings and use AI assist below.", color = Muted) }
                item { Button(enabled = !busy && request.isNotBlank() && apiKey.isNotBlank(), onClick = { busy = true; scope.launch { output = askAI(endpoint, apiKey, model, "Act as a software architect. Create a practical implementation plan for: $request. Target: ${target.ifBlank { "not specified" }}. Clearly state assumptions and output files/modules."); busy = false } }, modifier = Modifier.fillMaxWidth()) { Text("Ask cloud AI for an implementation plan") } }
            }
            2 -> LazyColumn(Modifier.weight(1f).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                item { Text("Inspection workbench", color = Color.White, style = MaterialTheme.typography.headlineSmall) }
                item { Text("Upstream Rust parsers via JNI: APK container inspection, executable format analysis and bounded printable-string extraction.", color = Muted) }
                item { Button(enabled = !busy && NativeEngine.available, onClick = { filePicker.launch(arrayOf("application/vnd.android.package-archive", "application/octet-stream", "application/zip", "*/*")) }, modifier = Modifier.fillMaxWidth()) { Text(if (!NativeEngine.available) "Native library not installed" else "Select APK / binary for Rust analysis") } }
                item { Text("Selected: $selectedFileName", color = Muted) }
                item { OutlinedTextField(target, { target = it }, label = { Text("Public website URL") }, modifier = Modifier.fillMaxWidth()) }
                item { Button(enabled = !busy && target.startsWith("https://"), onClick = { busy = true; scope.launch { output = inspectSite(target); busy = false } }, modifier = Modifier.fillMaxWidth()) { Text(if (busy) "Inspecting…" else "Run basic URL inspection") } }
                item { Text("Website URL check remains metadata-only. Native file analysis is performed locally by the upstream formats crate. It does not execute the selected app or bypass its protections.", color = Muted) }
                item { ResultCard(output) }
            }
            3 -> LazyColumn(Modifier.weight(1f).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                item { Text("AI coding-agent planner", color = Color.White, style = MaterialTheme.typography.headlineSmall) }
                item { Text("Create a structured implementation work order with cloud AI. Generated commands and code are proposals only; this Android starter does not execute them.", color = Muted) }
                item { OutlinedTextField(request, { request = it }, label = { Text("Describe the coding task") }, minLines = 4, modifier = Modifier.fillMaxWidth()) }
                item { OutlinedTextField(target, { target = it }, label = { Text("Target URL or project context") }, modifier = Modifier.fillMaxWidth()) }
                item { Button(enabled = !busy && request.isNotBlank() && apiKey.isNotBlank(), onClick = { busy = true; scope.launch { output = CodingAgent.prettyResult(askAI(endpoint, apiKey, model, CodingAgent.buildPrompt(request, target))); busy = false } }, modifier = Modifier.fillMaxWidth()) { Text(if (busy) "Agent planning…" else "Generate agent work order") } }
                item { Text("Human approval boundary", color = Color.White, fontWeight = FontWeight.Bold) }
                item { Text("No shell execution, app installation, signing, publishing, or deployment is performed by this module. Review any proposed code and commands before using them.", color = Muted) }
                item { ResultCard(output) }
            }
            else -> LazyColumn(Modifier.weight(1f).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                item { Text("AI provider settings", color = Color.White, style = MaterialTheme.typography.headlineSmall) }
                item { OutlinedTextField(endpoint, { endpoint = it }, label = { Text("OpenAI-compatible API base URL") }, modifier = Modifier.fillMaxWidth()) }
                item { OutlinedTextField(model, { model = it }, label = { Text("Model ID") }, modifier = Modifier.fillMaxWidth()) }
                item { OutlinedTextField(apiKey, { apiKey = it }, label = { Text("API key") }, modifier = Modifier.fillMaxWidth()) }
                item { Button(onClick = { prefs.edit().putString("endpoint", endpoint.trim()).putString("model", model.trim()).putString("key", apiKey.trim()).apply(); output = "Provider settings saved using Android encrypted preferences." }, modifier = Modifier.fillMaxWidth()) { Text("Save encrypted settings") } }
                item { Text("Use a provider endpoint you trust. API usage may incur charges. Never share your API key or commit it to source control.", color = Muted) }
                item { Text("Hybrid design", color = Color.White, fontWeight = FontWeight.Bold) }
                item { Text("On-device: project briefs and files. Cloud: optional AI planning via an OpenAI-compatible Chat Completions endpoint. A trusted remote worker is still required for actual agent-driven builds.", color = Muted) }
            }
        }
    }
}

@Composable private fun StatCard(title: String, value: String, detail: String, icon: androidx.compose.ui.graphics.vector.ImageVector) {
    Surface(color = Panel, shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) { Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) { Icon(icon, null, tint = Accent, modifier = Modifier.size(30.dp)); Spacer(Modifier.width(14.dp)); Column { Text(title, color = Muted, style = MaterialTheme.typography.labelSmall); Text(value, color = Color.White, fontWeight = FontWeight.Bold); Text(detail, color = Muted, style = MaterialTheme.typography.bodySmall) } } }
}
@Composable private fun ResultCard(value: String) { Surface(color = Panel, shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth()) { Text(value, color = Color.White, modifier = Modifier.padding(16.dp)) } }

private fun securePrefs(activity: ComponentActivity) = EncryptedSharedPreferences.create(activity, "craft_secure", MasterKey.Builder(activity).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build(), EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV, EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM)

private suspend fun createProject(activity: ComponentActivity, name: String, target: String, prompt: String): String = withContext(Dispatchers.IO) {
    val safe = name.trim().replace(Regex("[^A-Za-z0-9_-]"), "_").ifBlank { "Project" }
    val dir = File(activity.filesDir, "projects/$safe"); dir.mkdirs()
    val brief = JSONObject().put("name", name).put("target", target).put("request", prompt).put("status", "planned").put("createdAt", System.currentTimeMillis())
    File(dir, "craft-project.json").writeText(brief.toString(2))
    "Project saved locally: ${dir.name}\nBrief: craft-project.json\nNext: configure an AI provider to generate an implementation plan."
}

private suspend fun inspectSite(address: String): String = withContext(Dispatchers.IO) {
    try {
        val url = URL(address)
        require(url.protocol == "https") { "Only HTTPS targets are allowed." }
        val conn = (url.openConnection() as HttpURLConnection).apply { requestMethod = "HEAD"; connectTimeout = 10000; readTimeout = 10000; instanceFollowRedirects = true }
        conn.connect()
        val result = "URL: $address\nHTTP status: ${conn.responseCode}\nContent type: ${conn.contentType ?: "unknown"}\nServer: ${conn.getHeaderField("Server") ?: "not disclosed"}\nContent length: ${conn.contentLengthLong}\n\nThis is basic HTTP metadata only, not a full reverse-engineering report."
        conn.disconnect(); result
    } catch (e: Exception) { "Inspection failed: ${e.message}" }
}

private suspend fun askAI(base: String, key: String, model: String, prompt: String): String = withContext(Dispatchers.IO) {
    try {
        val root = base.trimEnd('/')
        require(root.startsWith("https://")) { "API endpoint must use HTTPS." }
        val payload = JSONObject().put("model", model).put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", prompt)))
        val body = payload.toString().toRequestBody("application/json".toMediaType())
        val client = OkHttpClient.Builder().callTimeout(90, TimeUnit.SECONDS).build()
        val req = Request.Builder().url("$root/chat/completions").header("Authorization", "Bearer $key").post(body).build()
        client.newCall(req).execute().use { response ->
            val text = response.body?.string().orEmpty()
            if (!response.isSuccessful) "AI request failed (${response.code}): ${text.take(1200)}"
            else JSONObject(text).optJSONArray("choices")?.optJSONObject(0)?.optJSONObject("message")?.optString("content") ?: "Provider returned no message."
        }
    } catch (e: Exception) { "AI request error: ${e.message}" }
}
