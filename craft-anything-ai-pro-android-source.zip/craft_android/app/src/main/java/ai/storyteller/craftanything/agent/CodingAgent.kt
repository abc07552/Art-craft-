package ai.storyteller.craftanything.agent

import org.json.JSONArray
import org.json.JSONObject

/** Creates a structured, reviewable cloud-agent work order. It never executes generated commands. */
object CodingAgent {
    fun buildPrompt(goal: String, target: String): String = """
        You are the Craft Anything AI PRO coding-agent planner.
        Return a JSON object with keys: summary, assumptions (array), proposed_files (array of
        objects with path and purpose), implementation_steps (array), verification (array),
        risks (array), commands_requiring_human_approval (array).
        Goal: $goal
        Target: ${target.ifBlank { "not specified" }}
        Rules: do not claim you inspected files you were not given; prefer minimal changes;
        never include secrets; do not run commands or deploy anything; mark destructive, network,
        privileged, signing, publishing and install actions as requiring explicit human approval.
    """.trimIndent()

    fun prettyResult(raw: String): String = try {
        val start = raw.indexOf('{')
        val end = raw.lastIndexOf('}')
        if (start >= 0 && end > start) JSONObject(raw.substring(start, end + 1)).toString(2) else raw
    } catch (_: Exception) { raw }
}
