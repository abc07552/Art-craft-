package ai.storyteller.craftanything

/** JNI facade over the upstream Craft Anything pure-Rust format parsers. */
object NativeEngine {
    val available: Boolean = try {
        System.loadLibrary("craft_anything_android")
        true
    } catch (_: UnsatisfiedLinkError) { false }

    external fun analyzeBinary(bytes: ByteArray): String
    external fun extractStrings(bytes: ByteArray): String
    external fun inspectApk(bytes: ByteArray): String
}
